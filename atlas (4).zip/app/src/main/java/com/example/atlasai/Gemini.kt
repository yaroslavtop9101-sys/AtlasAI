package com.example.atlasai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ошибка API. code: HTTP-код (0 = локальная ошибка приложения),
 * retryMs: сколько ждать по подсказке Google, daily: дневной лимит, unavailable: лимит равен нулю.
 */
class ApiException(
    val code: Int,
    message: String,
    val retryMs: Long = 0,
    val daily: Boolean = false,
    val unavailable: Boolean = false
) : Exception(message)

/** Клиент Google Gemini через REST. Вызывать только не из главного потока. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val IMAGE_MODEL = "gemini-3.1-flash-image"

    class Attachment(val mime: String, val b64: String)

    private fun apiError(code: Int, json: JSONObject): ApiException {
        val err = json.optJSONObject("error")
        val msg = err?.optString("message", "") ?: ""
        var retry = 0L
        var daily = msg.contains("per day", true) || msg.contains("PerDay", true)
        val details = err?.optJSONArray("details")
        if (details != null) {
            for (i in 0 until details.length()) {
                val d = details.optJSONObject(i) ?: continue
                val delay = d.optString("retryDelay", "")
                if (delay.isNotBlank()) {
                    Regex("[0-9.]+").find(delay)?.value?.toDoubleOrNull()?.let { retry = (it * 1000).toLong() }
                }
                val v = d.optJSONArray("violations")
                if (v != null) {
                    for (j in 0 until v.length()) {
                        val o = v.optJSONObject(j) ?: continue
                        val id = o.optString("quotaId", "") + o.optString("quotaMetric", "")
                        if (id.contains("PerDay", true)) daily = true
                    }
                }
            }
        }
        val unavailable = msg.contains("limit: 0")
        return ApiException(code, msg.ifBlank { "HTTP $code" }, retry, daily, unavailable)
    }

    private fun post(model: String, key: String, body: JSONObject): JSONObject {
        val c = URL("$BASE$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                throw ApiException(code, "HTTP $code")
            }
            if (code !in 200..299) throw apiError(code, json)
            return json
        } finally {
            c.disconnect()
        }
    }

    private fun textPart(t: String) = JSONObject().put("text", t)

    fun chat(
        key: String,
        model: String,
        system: String,
        history: List<Msg>,
        text: String,
        atts: List<Attachment>,
        search: Boolean
    ): String {
        val contents = JSONArray()
        for (m in history.takeLast(20)) {
            if (m.text.isBlank()) continue
            contents.put(
                JSONObject()
                    .put("role", if (m.fromUser) "user" else "model")
                    .put("parts", JSONArray().put(textPart(m.text)))
            )
        }
        val parts = JSONArray().put(textPart(if (text.isBlank()) "." else text))
        for (a in atts) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", a.mime).put("data", a.b64)
                )
            )
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(textPart(system))))
        if (search) {
            body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }

        val res = post(model, key, body)
        val out = StringBuilder()
        val ps = res.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        if (ps != null) {
            for (i in 0 until ps.length()) out.append(ps.getJSONObject(i).optString("text", ""))
        }
        if (out.isBlank()) {
            val reason = res.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            throw ApiException(0, if (reason.isNotBlank()) reason else "empty response")
        }
        return out.toString().trim()
    }

    /** Возвращает подпись и картинку. */
    fun image(key: String, prompt: String): Pair<String, Bitmap?> {
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(JSONObject().put("parts", JSONArray().put(textPart(prompt))))
            )
            .put(
                "generationConfig",
                JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
            )
        val res = post(IMAGE_MODEL, key, body)
        val ps = res.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw ApiException(0, "empty response")
        var caption = ""
        var bmp: Bitmap? = null
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            caption += p.optString("text", "")
            val inline = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
            if (inline != null) {
                val bytes = Base64.decode(inline.getString("data"), Base64.DEFAULT)
                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        }
        if (bmp == null) throw ApiException(0, "no image returned")
        return caption.trim() to bmp
    }
}
